public class Calc_Driver {
    public static void main(String[] args) {
        Calc_GUI calcGui = new Calc_GUI();
    }
}
